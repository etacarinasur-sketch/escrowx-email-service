ESCROWX EMAIL SERVICE — V2 BRANDED (PROPUESTA NO PUBLICADA)

Contenido:
- server_V2_BRANDED.js: versión independiente del server.js original.
- escrowx-logo-email.png: recorte del logo/wordmark extraído de la referencia visual aportada por el usuario.
- package.json: configuración original del servicio (sin cambios necesarios).

CAMBIOS DE PRESENTACIÓN:
- La plantilla de verificación mantiene código de seis dígitos, vencimiento de 15 minutos y avisos de seguridad.
- /send-email conserva el asunto y el texto, y envuelve el HTML recibido en una estructura visual EscrowX. Se intenta conservar el contenido del body y los bloques <style> del HTML original.
- La imagen de marca se adjunta como imagen inline CID en el MIME, no como una imagen única del email.
- Las rutas /health, /oauth/start, /oauth/callback, /send-verification y /send-email se mantienen.
- Gmail API, OAuth, variables de entorno y lógica financiera no se modifican intencionalmente.

NO PUBLICAR TODAVÍA:
- No se realizaron pruebas reales de entrega en Gmail ni pruebas visuales en Gmail Android/desktop.
- Debe revisarse la compatibilidad con todos los HTML reales del marketplace antes de desplegar.
- No se modificó index.html ni ningún flujo/API de RBL, REVO o USDT.
- Esta propuesta no corrige ni cambia políticas de email del marketplace.
- El archivo original server.js permanece sin cambios.

Instalación de prueba (solo después de revisión): mantener package.json y poner server_V2_BRANDED.js como server.js en una copia de staging, junto a escrowx-logo-email.png. No sustituir el servicio en producción sin aprobación y pruebas.
