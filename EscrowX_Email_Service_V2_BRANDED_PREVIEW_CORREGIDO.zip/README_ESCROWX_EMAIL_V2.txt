ESCROWX EMAIL SERVICE — V2 BRANDED (PREVIEW / NO PRODUCCIÓN)

Contenido del paquete:
- server_V2_BRANDED.js: servidor V2 independiente.
- escrowx-logo-email.png: logo incrustado como imagen inline (CID).
- package.json: configurado para iniciar server_V2_BRANDED.js.

Presentación:
- Plantilla de verificación con código de 6 dígitos y vencimiento de 15 minutos.
- /send-email conserva asunto y texto y coloca el HTML recibido dentro de una plantilla visual EscrowX.
- Mantiene las rutas /health, /oauth/start, /oauth/callback, /send-verification y /send-email.
- Usa Gmail API y las variables de entorno GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REFRESH_TOKEN, FROM_EMAIL, PUBLIC_BASE_URL y PORT.

IMPORTANTE:
- Este ZIP es una propuesta de prueba, no está certificado para producción.
- No se han realizado envíos reales ni pruebas visuales en Gmail móvil/escritorio.
- Probar únicamente en un servicio de staging separado, con variables propias y sin cambiar el servicio actual.
- Antes de cualquier despliegue, revisar los HTML reales de marketplace y comparar con el servidor original.
- No incluye ni modifica código de RBL, REVO, USDT, marketplace ni lógica financiera.
- No reemplazar el server.js original en producción hasta completar las pruebas y aprobar explícitamente el cambio.
